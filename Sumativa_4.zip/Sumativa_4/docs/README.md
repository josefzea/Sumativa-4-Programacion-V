# Documentación de la API

## Swagger UI

Vista general de todos los endpoints:

![Swagger Overview](Weather-Endpoints.png)

### GET /api/temperatures/
Listado de todas las temperaturas:

![GET Temperatures](Get-Tempetures.png)

### POST /api/temperatures/
Crear una nueva ciudad:

![POST Temperature](Post-Temperatures.png)

### PUT /api/temperatures/{id}/
Actualizar un registro:

![PUT Temperature](Put-Temperatures_1.png)
![PUT Temperature](Put-Temperatures_2.png)

### DELETE /api/temperatures/{id}/
Eliminar un registro:

![DELETE Temperature](Delete-Temperatures.png)

### Autenticación

Obtener token de usuario:

![Token Auth](Token.png)
![Token Auth](Token-Auth.png)
