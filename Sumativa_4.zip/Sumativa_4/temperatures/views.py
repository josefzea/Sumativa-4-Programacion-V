from rest_framework import viewsets, permissions
from .models import CityTemperature
from .serializers import CityTemperatureSerializer
from drf_yasg.utils import swagger_auto_schema
from drf_yasg import openapi


class CityTemperatureViewSet(viewsets.ModelViewSet):
    """
    API para gestionar las ciudades como un CRUD, permitiendo ver los detalles,
    instar nuevas ciudades con temperatiras, actualizar las ya existentes y
    borrar las que se desean.
    """

    queryset = CityTemperature.objects.all().order_by('-last_updated')
    serializer_class = CityTemperatureSerializer
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    # ===== LIST =====
    @swagger_auto_schema(
        operation_description="Lista todas las ciudades con sus temperaturas.",
        responses={200: CityTemperatureSerializer(many=True)}
    )
    def list(self, request, *args, **kwargs):
        return super().list(request, *args, **kwargs)

    # ===== RETRIEVE =====
    @swagger_auto_schema(
        operation_description="Obtiene los datos de una ciudad específica, usando su ID.",
        responses={200: CityTemperatureSerializer(), 404: "No encontrado"}
    )
    def retrieve(self, request, *args, **kwargs):
        return super().retrieve(request, *args, **kwargs)

    # ===== CREATE =====
    @swagger_auto_schema(
        operation_description="Crea un nuevo registro de ciudad con temperatura.",
        request_body=openapi.Schema(
            type=openapi.TYPE_OBJECT,
            required=['city', 'temperature'],
            properties={
                'city': openapi.Schema(type=openapi.TYPE_STRING, description='Nombre de la ciudad', example='Santiago'),
                'temperature': openapi.Schema(type=openapi.TYPE_NUMBER, description='Temperatura en grados', example=28.4),
            }
        ),
        responses={
            201: CityTemperatureSerializer(),
            400: "Error en los datos enviados"
        }
    )
    def create(self, request, *args, **kwargs):
        return super().create(request, *args, **kwargs)

    # ===== UPDATE =====
    @swagger_auto_schema(
        operation_description="Actualiza los datos de una ciudad existente.",
        request_body=CityTemperatureSerializer,
        responses={
            200: CityTemperatureSerializer(),
            400: "Datos inválidos",
            404: "Ciudad no encontrada"
        }
    )
    def update(self, request, *args, **kwargs):
        return super().update(request, *args, **kwargs)

    # ===== DELETE =====
    @swagger_auto_schema(
        operation_description="Elimina una ciudad según el ID proporcionado.",
        responses={
            204: "Eliminado correctamente",
            404: "Ciudad no encontrada"
        }
    )
    def destroy(self, request, *args, **kwargs):
        return super().destroy(request, *args, **kwargs)
